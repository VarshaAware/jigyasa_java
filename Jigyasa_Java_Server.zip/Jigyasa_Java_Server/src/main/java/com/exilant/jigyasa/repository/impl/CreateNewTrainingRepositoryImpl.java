/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTrainingRepositoryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.CreateNewTrainingRepository;
import com.exilant.jigyasa.vo.CreateNewTraining;
import com.exilant.jigyasa.vo.Employee;
import com.exilant.jigyasa.vo.Schedule;
import com.exilant.jigyasa.vo.TrainerList;

/**
 * @author swathi.m
 *
 */
@Repository
public class CreateNewTrainingRepositoryImpl implements CreateNewTrainingRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.repository.CreateNewTrainingRepository#
	 * createNewTraining(com.exilant.jigyasa.vo.CreateNewTraining)
	 */

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Boolean createNewTraining(CreateNewTraining createNewTraining) {
		// TODO Auto-generated method stub

		String sqlCourses = SqlQueryConstants.INSERT_COURSES;
		Object[] queryParameters = new Object[] { createNewTraining.getTraining().getTitle(),
				createNewTraining.getTraining().getImage(), createNewTraining.getTraining().getDescription(),
				createNewTraining.getTraining().getLink() };
		int result = jdbcTemplate.update(sqlCourses, queryParameters);
		if (result != 0) {
			String sqlCourseId = SqlQueryConstants.GET_COURSE_ID;
			int courseId = jdbcTemplate.queryForObject(sqlCourseId, Integer.class);
			//System.out.println("*********************" + createNewTraining.getSchedule());
			int trainingLocationId = 0;
			for (Schedule schedule : createNewTraining.getSchedule()) {
				String sqlTrainingLocationId = SqlQueryConstants.GET_TRAINING_LOCATION_ID;
				trainingLocationId = jdbcTemplate.queryForObject(sqlTrainingLocationId, Integer.class,
						schedule.getLocation());
				//System.out.println("/////// ///@@@@@//////////" + trainingLocationId);
			}

			//System.out.println("+++++++++++++++++++++++" + courseId);
			String sqlscheduledTraining = SqlQueryConstants.INSERT_SCHEDULED_TRAINING;
			Object[] scheduledTrainingQueryParameters = new Object[] { courseId, trainingLocationId,
					createNewTraining.getTraining().getSeats() };
			jdbcTemplate.update(sqlscheduledTraining, scheduledTrainingQueryParameters);

			//System.out.println("+++++++++++@@@@++++++++++++" + createNewTraining.getSchedule());

			Schedule schedule = createNewTraining.getSchedule().get(0);
			String sqlScheduleTime = SqlQueryConstants.INSERT_SCHEDULED_TRAINING_TIME;
			Object[] scheduleTimeQueryParameters = new Object[] { trainingLocationId, schedule.getStartDate(),
					schedule.getEndDate() };
			jdbcTemplate.update(sqlScheduleTime, scheduleTimeQueryParameters);

			for (TrainerList trainerlist : createNewTraining.getTrainerList()) {
				String sqlTrainers = SqlQueryConstants.INSERT_TRAINERS;
				Object[] trainerQueryParameters = new Object[] { trainerlist.getEmployeeId() };
				jdbcTemplate.update(sqlTrainers, trainerQueryParameters);
			}

			String sqlNotification = SqlQueryConstants.INSERT_TRAINING_NOTIFICATIONS;
			Object[] notificationQueryParameters = new Object[] { trainingLocationId,
					createNewTraining.getNotification().getType(), createNewTraining.getNotification().getSubject(),
					createNewTraining.getNotification().getContent(),
					createNewTraining.getNotification().getCcListId() };
			jdbcTemplate.update(sqlNotification, notificationQueryParameters);
		}
		return true;

	}

}
