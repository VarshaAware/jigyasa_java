package com.exilant.jigyasa.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.UpdateSuggestionTrainingStatusController;
import com.exilant.jigyasa.service.UpdateSuggestionTrainingStatusService;
import com.exilant.jigyasa.vo.SuggestTraining;

@RestController
@CrossOrigin
public class UpdateSuggestionTrainingStatusControllerImpl implements UpdateSuggestionTrainingStatusController {
	@Autowired
	UpdateSuggestionTrainingStatusService updateSuggestionTrainingStatusService;

	@Override
	@RequestMapping(value = URIConstants.UPDATE_SUGGEST_TRAINING_STATUS, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> updateSuggestionTrainingStatus(@RequestBody SuggestTraining reqObj) throws Exception {
		boolean val = updateSuggestionTrainingStatusService.updateSuggestionTrainingStatusService(reqObj);
		if (val) {
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		return ResponseEntity.badRequest().body("Failed");
	}
}