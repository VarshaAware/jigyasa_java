package com.exilant.jigyasa.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.ColumnNameConstants;
import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.TrainingDetailsRepository;
import com.exilant.jigyasa.vo.Scheduled_Training;
import com.exilant.jigyasa.vo.TrainingList;

@Repository
public class MySqlTrainingDetailsRepository implements TrainingDetailsRepository{

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String trainingDetails(TrainingList trainingList) {
		String query = SqlQueryConstants.GET_SCHEDULED_TRAINING;
		int input = trainingList.getTrainingId();

		Scheduled_Training trainingObj = (Scheduled_Training) jdbcTemplate.queryForObject(query, new Object[] { input },
				(rs, rowNum) -> new Scheduled_Training(rs.getInt(ColumnNameConstants.SCHEDULED_TRAINING_ID)));
		if (trainingObj != null) {
			String queryToGetCourseDetails="SELECT Course_Name, Course_Description, Course_Links FROM Courses WHERE Course_Id = ?";
			int courseId= trainingList.getCourseId();
			
			TrainingList trainingListObj= jdbcTemplate.queryForObject(query, new Object[] { input },
					(rs, rowNum) -> new TrainingList(rs.getInt(ColumnNameConstants.COURSE_ID)));
			
			
			
		}
		return "";
	}
	

}
