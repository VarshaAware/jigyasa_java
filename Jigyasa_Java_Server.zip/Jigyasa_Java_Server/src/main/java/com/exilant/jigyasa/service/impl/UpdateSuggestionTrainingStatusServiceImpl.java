package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.UpdateSuggestionTrainingStatusRepository;
import com.exilant.jigyasa.service.UpdateSuggestionTrainingStatusService;
import com.exilant.jigyasa.vo.SuggestTraining;

@Service
public class UpdateSuggestionTrainingStatusServiceImpl implements UpdateSuggestionTrainingStatusService{
	@Autowired
	UpdateSuggestionTrainingStatusRepository updateSuggestionTrainingStatusRepository;

	@Override
	public Boolean updateSuggestionTrainingStatusService(SuggestTraining updateSuggestionTrainingStatus) {
		return updateSuggestionTrainingStatusRepository.updateSuggestionTrainingStatus(updateSuggestionTrainingStatus);
	}


}
