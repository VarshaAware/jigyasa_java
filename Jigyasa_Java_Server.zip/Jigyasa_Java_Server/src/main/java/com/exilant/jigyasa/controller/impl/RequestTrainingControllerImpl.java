package com.exilant.jigyasa.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.RequestTrainingController;
import com.exilant.jigyasa.service.RequestTrainingService;
import com.exilant.jigyasa.vo.RequestTraining;

@RestController
@CrossOrigin
public class RequestTrainingControllerImpl implements RequestTrainingController{
	@Autowired
	RequestTrainingService requestTrainingService;

	@Override
	@RequestMapping(value = URIConstants.REQUEST_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> RequestManagerToNominateForTraining(@RequestBody RequestTraining reqObj) throws Exception {
		boolean val = requestTrainingService.scheduledTraining(reqObj);
		if(val){
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		return ResponseEntity.badRequest().body("Failed");
	}
}
