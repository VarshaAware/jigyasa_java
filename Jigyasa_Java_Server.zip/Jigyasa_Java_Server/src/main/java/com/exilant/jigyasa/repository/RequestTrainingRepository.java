package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.RequestTraining;

public interface RequestTrainingRepository {
	boolean scheduledTraining(RequestTraining scheduledTrainingRequest);
}
