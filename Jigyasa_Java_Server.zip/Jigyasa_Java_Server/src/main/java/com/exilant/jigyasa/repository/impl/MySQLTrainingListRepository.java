/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * MySQLTrainingListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.repository.TrainingListRepository;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.ScheduledTrainingTime;
import com.exilant.jigyasa.vo.Scheduled_Training;
import com.exilant.jigyasa.vo.Training;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLTrainingListRepository implements TrainingListRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<MyTraining> getTrainingListForAdmin(int employeeId, int roleId) {
		List<MyTraining> myTrainingList = getMyTrainings(employeeId);
		String allTrainingList = getAllTrainings(roleId);
		String todayTrainingList = getTodayTrainingList();
		String suggestedTainingList = getSuggestedTainings(employeeId);
		return myTrainingList;
	}

	@Override
	public String getTrainingListForManager(int employeeId, int roleId) {
		return null;
	}

	@Override
	public String getTrainingListForEmployee(int employeeId, int roleId) {

		return null;
	}

	private List<MyTraining> getMyTrainings(int employeeId) {
		List<MyTraining> myTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = dateFormat.format(new Date());
		String declined = "Declined";

		String sqlToGetMyTrainingId = " SELECT stn.Scheduled_Training_Id FROM Scheduled_Training_Nominee as stn inner join Scheduled_Training_Time as stt on stn.Scheduled_Training_Id = stt.Scheduled_Training_Id WHERE stn.Training_nominee_Id = ? and stn.Status != ? and stt.Training_End_Time >= ? ";
		Object[] queryParameters = new Object[] { employeeId, declined, date };
		List<Integer> myTrainingId = jdbcTemplate.query(sqlToGetMyTrainingId, queryParameters,
				(rs, rowNum) -> rs.getInt(1));

		String approved = "Approved";
		String sqlToGetMyTrainingId1 = " SELECT str.Scheduled_Training_Id FROM trainingappdb.Scheduled_Training_Request as str inner join Scheduled_Training_Time as stt on str.Scheduled_Training_Id = stt.Scheduled_Training_Id where str.Training_requestor_Id = ? and str.Status = ? and stt.Training_End_Time >= ?;";
		Object[] queryParameters1 = new Object[] { employeeId, approved, date };
		List<Integer> myTrainingId1 = jdbcTemplate.query(sqlToGetMyTrainingId1, queryParameters1,
				(rs, rowNum) -> rs.getInt(1));
		for (Integer val : myTrainingId1) {
			myTrainingId.add(val);
		}
		if (myTrainingId.size() > 1) {
			for (Integer i : myTrainingId) {
				String sql = "SELECT Course_Id, Training_Location_Id FROM Scheduled_Training where Scheduled_Training_Id = ?";
				Scheduled_Training schecduledTraining = jdbcTemplate.queryForObject(sql, new Object[] { i },
						(rs, rowNum) -> {
							Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
							schecduledTrainingObj.setCourseId(rs.getInt(1));
							schecduledTrainingObj.setTrainingLocationId(rs.getInt(2));
							return schecduledTrainingObj;
						});

				Training course = null;
				if (schecduledTraining.getCourseId() != 0) {
					String sql1 = "SELECT Course_Name, Course_Image, Course_Description FROM Courses WHERE Course_Id = ?";
					course = jdbcTemplate.queryForObject(sql1, new Object[] { schecduledTraining.getCourseId() },
							(rs, rowNum) -> {
								Training courseObj = new Training();
								courseObj.setTitle(rs.getString(1));
								courseObj.setImage(rs.getString(2));
								courseObj.setDescription(rs.getString(3));
								return courseObj;
							});
				}

				String queryToGetLocation = "SELECT Training_Room FROM Training_Location WHERE Training_Location_Id = ?";
				String trainingRoom = jdbcTemplate.queryForObject(queryToGetLocation,
						new Object[] { schecduledTraining.getTrainingLocationId() }, String.class);

				String queryToGetStartAndEndTime = "SELECT Training_Start_Time, Training_End_Time FROM Scheduled_Training_Time WHERE Scheduled_Training_Id = ?";
				ScheduledTrainingTime time = jdbcTemplate.queryForObject(queryToGetStartAndEndTime, new Object[] { i },
						(rs, rowNum) -> {
							ScheduledTrainingTime timeObj = new ScheduledTrainingTime();
							timeObj.setStartDate(rs.getString(1));
							timeObj.setEndDate(rs.getString(2));
							return timeObj;
						});

				MyTraining myTraining = new MyTraining();
				myTraining.setLoaction(trainingRoom);
				myTraining.setEndDate(time.getEndDate());
				myTraining.setImage(course.getImage());
				myTraining.setTrainingId(i);
				myTraining.setDescription(course.getDescription());
				myTraining.setTitle(course.getTitle());
				myTraining.setStartDate(time.getStartDate());

				myTrainings.add(myTraining);
			}
		}
		return myTrainings;
	}

	private String getAllTrainings(int roleId) {
		List<MyTraining> myTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = dateFormat.format(new Date());
		
		String sql = "SELECT st.Scheduled_Training_Id,st.Course_Id, st.Training_Location_Id,st.Seats FROM Scheduled_Training as st inner join trainingappdb.Scheduled_Training_Time as stt on st.Scheduled_Training_Id = stt.Scheduled_Training_Id  where stt.Training_Start_Time > ? ";
		List<Scheduled_Training> schecduledTrainings = jdbcTemplate.query(sql, new Object[] { date }, (rs, rowNum) -> {
			 Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
			 	schecduledTrainingObj.setScheduled_Training_Id(rs.getInt(1));
				schecduledTrainingObj.setCourseId(rs.getInt(2));
				schecduledTrainingObj.setTrainingLocationId(rs.getInt(3));
				return schecduledTrainingObj;
		 });
		if(schecduledTrainings.size() > 0){
			for (Scheduled_Training schecduledTraining : schecduledTrainings){
				
			}
		}
		return null;
	}

	private String getTodayTrainingList() {
		return null;
	}

	private String getSuggestedTainings(int employeeId) {
		return null;
	}

}
