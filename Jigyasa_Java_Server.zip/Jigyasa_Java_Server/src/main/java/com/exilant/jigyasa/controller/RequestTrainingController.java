package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;

import com.exilant.jigyasa.vo.RequestTraining;

public interface RequestTrainingController {
	ResponseEntity<?> RequestManagerToNominateForTraining(RequestTraining reqObj) throws Exception;
}
