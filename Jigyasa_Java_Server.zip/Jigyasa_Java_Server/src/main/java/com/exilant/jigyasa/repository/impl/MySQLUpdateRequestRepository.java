/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 02-May-2017
  * MySQLUpdateRequestRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.UpdateRequestRepository;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLUpdateRequestRepository implements UpdateRequestRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean updateRequest(RequestTraining obj) {
		int n=0;
		for (Integer i : obj.getEmployeeIdList()) {
			String sql = SqlQueryConstants.UPDATE_TRAINING_REQUEST;
			Object[] queryParameters = new Object[] { obj.getStatus(), obj.getTrainingId(), i.intValue() };
			n = jdbcTemplate.update(sql, queryParameters);
		}
		if(n!=0){
			return true;
		}
		return false;
	}

}
