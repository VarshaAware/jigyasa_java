/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * NominateForTrainingServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.NominateForTrainingRepository;
import com.exilant.jigyasa.service.NominateForTrainingService;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class NominateForTrainingServiceImpl implements NominateForTrainingService{

	@Autowired
	NominateForTrainingRepository nominateForTrainingRepository;

	@Override
	public boolean nominateEmp(ScheduledTrainingNominee nominee) {
		return nominateForTrainingRepository.nominateEmp(nominee);
	}

}
