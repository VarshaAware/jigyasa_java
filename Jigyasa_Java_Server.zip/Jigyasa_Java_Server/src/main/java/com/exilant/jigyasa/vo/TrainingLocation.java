/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 28-Apr-2017
>  * TrainingLocation.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class TrainingLocation {
private String location;

public TrainingLocation() {
	super();
}

public TrainingLocation(String location) {
	super();
	this.location = location;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

@Override
public String toString() {
	return "TrainingLocation [location=" + location + "]";
}


}
