/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * NominateForTrainingService.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.ScheduledTrainingNominee;

/**
 * @author lakshmi.bhat
 *
 */
public interface NominateForTrainingService {
	boolean nominateEmp(ScheduledTrainingNominee nominee);
}
