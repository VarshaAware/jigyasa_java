/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTrainingServiceImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.CreateNewTrainingRepository;

import com.exilant.jigyasa.service.CreateNewTrainingService;
import com.exilant.jigyasa.vo.CreateNewTraining;


/**
 * @author swathi.m
 *
 */
@Service
public class CreateNewTrainingServiceImpl implements CreateNewTrainingService {

	/* (non-Javadoc)
	 * @see com.exilant.jigyasa.service.CreateNewTrainingService#loginService(com.exilant.jigyasa.vo.CreateNewTraining)
	 */
	@Autowired
	CreateNewTrainingRepository createNewTrainingRepository;
	
	@Override
	public boolean createNewTrainingService(CreateNewTraining createNewTraining) {
		// TODO Auto-generated method stub
		boolean createsNewTraining = createNewTrainingRepository.createNewTraining(createNewTraining);
		return createsNewTraining;
	}

}
