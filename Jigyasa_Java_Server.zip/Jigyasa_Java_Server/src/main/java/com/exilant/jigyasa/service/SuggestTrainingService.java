package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface SuggestTrainingService {
	Boolean suggestTraining(SuggestTraining suggestTrainingRequest);
}
