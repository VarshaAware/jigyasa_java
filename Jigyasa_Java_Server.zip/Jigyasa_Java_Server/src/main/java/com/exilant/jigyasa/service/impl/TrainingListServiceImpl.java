/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.TrainingListRepository;
import com.exilant.jigyasa.service.TrainingListService;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.TrainingList;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class TrainingListServiceImpl implements TrainingListService{
	static final Logger logger = LoggerFactory.getLogger(TrainingListServiceImpl.class);

	@Autowired
	TrainingListRepository trainingListRepository;
	List<MyTraining> result = new ArrayList<MyTraining>();
	@Override
	public List<MyTraining> getTrainingList(TrainingList trainingList) {
		if(trainingList.getEmployeeId() == 0){
			logger.error("Employee Id is missing");
		}else{
			switch(trainingList.getDesignation()){
			case 1: result = trainingListRepository.getTrainingListForAdmin(trainingList.getEmployeeId(), trainingList.getDesignation());
				break;
			case 2: 
				//result = trainingListRepository.getTrainingListForManager(trainingList.getEmployeeId(), trainingList.getDesignation());
				break;
			default: 
				//result = trainingListRepository.getTrainingListForEmployee(trainingList.getEmployeeId(), trainingList.getDesignation());
			}
		}
		return result;
	}

}
