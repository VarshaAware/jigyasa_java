package com.exilant.jigyasa.repository;


import com.exilant.jigyasa.vo.TrainingList;

public interface TrainingDetailsRepository {
	String trainingDetails(TrainingList trainingList);
}
