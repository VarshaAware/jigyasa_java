/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * SqlQueryConstants.java
  *
  *******************************************************/

package com.exilant.jigyasa.constants;

/**
 * @author lakshmi.bhat
 *
 */
public class SqlQueryConstants {
	public static final String GET_EMPLOYEE_DETAILS = "SELECT * FROM Employees WHERE Email_Id = ?";
	public static final String GET_SCHEDULED_TRAINING = "SELECT * FROM Scheduled_Training where Scheduled_Training_Id = ?";
	public static final String INSERT_REQUEST_TRAINING = " INSERT INTO Scheduled_Training_Request (Scheduled_Training_Id, Training_requestor_Id, Training_requestor_Name, Training_requestor_ManagerId) VALUES (?,?,?,?)";
	public static final String INSERT_SUGGEST_TRAINING ="INSERT INTO Courses (Course_Name, Course_Description, Course_Suggested_By) VALUES (?,?,?)";
	public static final String INSERT_SCHEDULED_TRAINING_NOMINEE = "Insert into Scheduled_Training_Nominee (Scheduled_Training_Id, Training_nominee_Id, Training_nominee_ManagerId, Status) values (?,?,?,?)";
	public static final String UPDATE_SCHEDULED_TRAINING_STATUS="Update Courses set Course_Status = ? WHERE Course_Name = ? AND Course_Suggested_By = ?"; 
	public static final String UPDATE_TRAINING_REQUEST = "Update Scheduled_Training_Request set Status = ? WHERE Scheduled_Training_Id = ? AND Training_requestor_Id = ?";
	public static final String INSERT_COURSES = "INSERT INTO Courses(Course_Name, Course_Image, Course_Description, Course_Links)  VALUES (?, ?, ?, ?)";
	public static final String GET_COURSE_ID = "SELECT Course_Id from Courses ORDER BY Course_Id DESC LIMIT 1";
	public static final String GET_TRAINING_LOCATION_ID ="SELECT Training_Location_Id FROM Training_Location where Training_Room = ?";
	public static final String INSERT_SCHEDULED_TRAINING = "INSERT INTO Scheduled_Training(Course_Id,Training_Location_Id,Seats) VALUES(?,?,?)";
	public static final String INSERT_SCHEDULED_TRAINING_TIME = "INSERT INTO Scheduled_Training_Time(Scheduled_Training_Id,Training_Start_Time , Training_End_Time) VALUES (?,?,?)";
	public static final String INSERT_TRAINERS = "INSERT INTO Trainers(Trainer_Id) VALUES (?)";
	public static final String INSERT_TRAINING_NOTIFICATIONS = "INSERT INTO Training_Notifications(Scheduled_Training_Id, Mail_Notification_Type, Mail_Notification_Subject, Mail_Notification_Content, CC_List_ID) VALUES (?, ?, ?, ?, ?)";
	
}
