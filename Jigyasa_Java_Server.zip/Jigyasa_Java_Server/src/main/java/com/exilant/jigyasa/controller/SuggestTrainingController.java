package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface SuggestTrainingController {
	ResponseEntity<?> SuggestTraining(SuggestTraining reqObj) throws Exception;
}
