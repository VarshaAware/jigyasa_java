/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * URIConstants.java
  *
  *******************************************************/

package com.exilant.jigyasa.constants;

/**
 * @author lakshmi.bhat
 *
 */
public class URIConstants {
	public static final String LOGIN = "/Jigyasa/Login";
	public static final String REQUEST_TRAINING = "/Jigyasa/RequestManagerToNominateForTraining";
	public static final String SUGGEST_TRAINING = "/Jigyasa/SuggestTraining";
	public static final String NOMINATE_TRAINING = "/Jigyasa/NominateTraining";
	public static final String UPDATE_SUGGEST_TRAINING_STATUS="/Jigyasa/UpdateSuggestionStatus";
	public static final String UPDATE_REQUEST_STATUS = "/Jigyasa/UpdateRequestStatus";
	public static final String CREATE_NEW_TRAINING = "/Jigyasa/CreateTrainingHandler";
}
