/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * Training.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class Training {
	private String title;
	private String description;
	private int seats;
	private String link;
	private String image;
	public Training() {
		super();
	}
	public Training(String title, String description, int seats, String link, String image) {
		super();
		this.title = title;
		this.description = description;
		this.seats = seats;
		this.link = link;
		this.image = image;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Training [title=" + title + ", description=" + description + ", seats=" + seats + ", link=" + link
				+ ", image=" + image + "]";
	}

	
	
}
