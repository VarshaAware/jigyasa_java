package com.exilant.jigyasa.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.RequestTrainingRepository;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Scheduled_Training;

@Repository
public class MySqlRequestTrainingRepository implements RequestTrainingRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean scheduledTraining(RequestTraining scheduledTrainingRequest) {

		String query = SqlQueryConstants.GET_SCHEDULED_TRAINING;
		int input = scheduledTrainingRequest.getTrainingId();

		Scheduled_Training trainingObj = (Scheduled_Training) jdbcTemplate.queryForObject(query, new Object[] { input },
				(rs, rowNum) -> {
					Scheduled_Training obj = new Scheduled_Training();
					obj.setScheduled_Training_Id(rs.getInt(1));
					return obj;
				});
		if (trainingObj != null) {
			String sql = SqlQueryConstants.INSERT_REQUEST_TRAINING;
			Object[] queryParameters = new Object[] { scheduledTrainingRequest.getTrainingId(),
					scheduledTrainingRequest.getEmployeeId(), scheduledTrainingRequest.getEmployeeName(),
					scheduledTrainingRequest.getManagerId() };

			jdbcTemplate.update(sql, queryParameters);
			return true;
		}

		return false;

	}

}
