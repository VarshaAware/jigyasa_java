package com.exilant.jigyasa.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.repository.SuggestTrainingRepository;
import com.exilant.jigyasa.vo.SuggestTraining;

@Repository
public class MySqlSuggestTrainingRepository implements SuggestTrainingRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean suggestTraining(SuggestTraining suggestTrainingRequest) {

		String sql = SqlQueryConstants.INSERT_SUGGEST_TRAINING;
		Object[] queryParameters = new Object[] { suggestTrainingRequest.getTitle(),
				suggestTrainingRequest.getDescription(), suggestTrainingRequest.getEmployeeId() };

		jdbcTemplate.update(sql, queryParameters);
		return true;

	}

}
