package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface UpdateSuggestionTrainingStatusRepository {
	boolean updateSuggestionTrainingStatus(SuggestTraining updateSuggestionTrainingStatus);

}
