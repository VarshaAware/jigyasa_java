/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListControllerImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.TrainingListController;
import com.exilant.jigyasa.service.TrainingListService;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.TrainingList;

/**
 * @author lakshmi.bhat
 *
 */
@Controller
public class TrainingListControllerImpl implements TrainingListController{

	@Autowired
	TrainingListService trainingListService;
	
	@Override
	@RequestMapping(value = "/Jigyasa/TrainingList", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getTrainingList(@RequestBody TrainingList trainingList) throws Exception {
		List<MyTraining> result= trainingListService.getTrainingList(trainingList);
		return new ResponseEntity<List<MyTraining>>(result, HttpStatus.OK);
	}

}
