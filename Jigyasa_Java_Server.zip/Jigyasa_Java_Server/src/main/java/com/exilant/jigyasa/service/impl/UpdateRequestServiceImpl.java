/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 02-May-2017
  * UpdateRequestServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.controller.impl.NominateForTrainingControllerImpl;
import com.exilant.jigyasa.repository.UpdateRequestRepository;
import com.exilant.jigyasa.service.UpdateRequestService;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class UpdateRequestServiceImpl implements UpdateRequestService{
	static final Logger logger = LoggerFactory.getLogger(NominateForTrainingControllerImpl.class);

	@Autowired
	UpdateRequestRepository updateRequestRepository;
	@Override
	public boolean updateRequestService(RequestTraining obj) {
		if(obj.getEmployeeIdList().isEmpty()){
			logger.error("Employee id missing");
			return false;
		}
		if(obj.getTrainingId()==0){
			logger.error("Training id missing");
			return false;
		}
		return updateRequestRepository.updateRequest(obj);
	}

}
