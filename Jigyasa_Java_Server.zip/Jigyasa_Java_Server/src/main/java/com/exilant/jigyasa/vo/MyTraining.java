/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * MyTraining.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

/**
 * @author lakshmi.bhat
 *
 */
public class MyTraining {
	private String loaction;
	private String endDate;
	private String image;
	private int trainingId;
	private String description;
	private String title;
	private String startDate;
	
	public MyTraining() {}
	
	public MyTraining(String loaction, String endDate, String image, int trainingId, String description, String title,
			String startDate) {
		super();
		this.loaction = loaction;
		this.endDate = endDate;
		this.image = image;
		this.trainingId = trainingId;
		this.description = description;
		this.title = title;
		this.startDate = startDate;
	}

	/**
	 * @return the loaction
	 */
	public String getLoaction() {
		return loaction;
	}

	/**
	 * @param loaction the loaction to set
	 */
	public void setLoaction(String loaction) {
		this.loaction = loaction;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * @return the trainingId
	 */
	public int getTrainingId() {
		return trainingId;
	}

	/**
	 * @param trainingId the trainingId to set
	 */
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MyTraining [loaction=" + loaction + ", endDate=" + endDate + ", image=" + image + ", trainingId="
				+ trainingId + ", description=" + description + ", title=" + title + ", startDate=" + startDate + "]";
	}

}
