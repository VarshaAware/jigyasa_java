/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * ColumnNameConstants.java
  *
  *******************************************************/

package com.exilant.jigyasa.constants;

/**
 * @author lakshmi.bhat
 *
 */
public class ColumnNameConstants {
	public static final String EMPLOYEE_ID = "Employee_Id";
	public static final String EMPLOYEE_NAME = "Employee_Name";
	public static final String EMAIL_ID = "Email_Id";
	public static final String ACTIVE = "Active";
	public static final String ROLE_ID = "Role_Id";
	public static final String CONTACT_NO = "Contact_No";
	public static final String MANAGER_ID = "Manager_Id";
	public static final String DESIGNATION = "Designation";

	public static final String SCHEDULED_TRAINING_ID = "Scheduled_Training_Id";
}
