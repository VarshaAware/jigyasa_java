package com.exilant.jigyasa.vo;

public class SuggestTraining {
	private int employeeId;
	private String title;
	private String description;
	private String status;
	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SuggestTraining() {
		super();
	}

	public SuggestTraining(int employeeId, String title, String description) {
		super();
		this.employeeId = employeeId;
		this.title = title;
		this.description = description;
	}

	@Override
	public String toString() {
		return "SuggestTraining [employeeId=" + employeeId + ", title=" + title + ", description=" + description
				+ ", status=" + status + "]";
	}



}
