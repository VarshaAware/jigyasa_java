/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 28-Apr-2017
>  * ScheduledTrainingTime.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class ScheduledTrainingTime {
private String startDate;
private String endDate;
public ScheduledTrainingTime() {
	super();
}
public ScheduledTrainingTime(String startDate, String endDate) {
	super();
	this.startDate = startDate;
	this.endDate = endDate;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
@Override
public String toString() {
	return "ScheduledTrainingTime [startDate=" + startDate + ", endDate=" + endDate + "]";
}


}
