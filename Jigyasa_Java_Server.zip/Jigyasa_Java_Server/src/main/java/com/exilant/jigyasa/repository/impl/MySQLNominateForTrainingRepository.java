/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * MySQLNominateForTrainingRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.NominateForTrainingRepository;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLNominateForTrainingRepository implements NominateForTrainingRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean nominateEmp(ScheduledTrainingNominee nominee) {
		nominee.setStatus("Nominated");
		for (Integer i : nominee.getNomineeId()) {
			String sql = SqlQueryConstants.INSERT_SCHEDULED_TRAINING_NOMINEE;
			Object[] queryParameters = new Object[] { nominee.getTrainingId(), i.intValue(), nominee.getEmployeeId(),
					nominee.getStatus() };
			jdbcTemplate.update(sql, queryParameters);
		}
		return true;
	}

}
