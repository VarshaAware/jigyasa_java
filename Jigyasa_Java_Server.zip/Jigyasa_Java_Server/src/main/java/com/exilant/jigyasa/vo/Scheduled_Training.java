package com.exilant.jigyasa.vo;

public class Scheduled_Training {
	private int Scheduled_Training_Id;
	private int courseId;
	private int trainingLocationId;

	public Scheduled_Training() {
	}

	public Scheduled_Training(int scheduled_Training_Id, int courseId, int trainingLocationId) {
		super();
		Scheduled_Training_Id = scheduled_Training_Id;
		this.courseId = courseId;
		this.trainingLocationId = trainingLocationId;
	}

	public int getScheduled_Training_Id() {
		return Scheduled_Training_Id;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public int getTrainingLocationId() {
		return trainingLocationId;
	}

	public void setTrainingLocationId(int trainingLocationId) {
		this.trainingLocationId = trainingLocationId;
	}

	public void setScheduled_Training_Id(int scheduled_Training_Id) {
		Scheduled_Training_Id = scheduled_Training_Id;
	}

	@Override
	public String toString() {
		return "Scheduled_Training [Scheduled_Training_Id=" + Scheduled_Training_Id + ", courseId=" + courseId
				+ ", trainingLocationId=" + trainingLocationId + "]";
	}

}
