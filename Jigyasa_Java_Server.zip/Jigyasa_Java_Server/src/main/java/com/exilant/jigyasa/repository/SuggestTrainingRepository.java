package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface SuggestTrainingRepository {
	boolean suggestTraining(SuggestTraining suggestTrainingRequest);
}
