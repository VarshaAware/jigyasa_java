/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 02-May-2017
  * UpdateRequsetControllerImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.UpdateRequestController;
import com.exilant.jigyasa.service.UpdateRequestService;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@RestController
public class UpdateRequsetControllerImpl implements UpdateRequestController {

	@Autowired
	UpdateRequestService updateRequestService;

	@Override
	@RequestMapping(value = URIConstants.UPDATE_REQUEST_STATUS, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> updateRequestStatus(@RequestBody RequestTraining requestTrainingObj) throws Exception {
		boolean val = updateRequestService.updateRequestService(requestTrainingObj);
		if (val) {
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		return ResponseEntity.badRequest().body("Failed: No such training request exist");
	}

}
