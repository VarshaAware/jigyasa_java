package com.exilant.jigyasa.vo;

import java.util.List;

public class RequestTraining {
	private int employeeId;
	private String employeeName;
	private int managerId;
	private int trainingId;
	private String status;
	private List<Integer> employeeIdList;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the employeeIdList
	 */
	public List<Integer> getEmployeeIdList() {
		return employeeIdList;
	}

	/**
	 * @param employeeIdList the employeeIdList to set
	 */
	public void setEmployeeIdList(List<Integer> employeeIdList) {
		this.employeeIdList = employeeIdList;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	public RequestTraining() {
		super();
	}

	public RequestTraining(int employeeId, String employeeName, int managerId, int trainingId, String status,
			List<Integer> employeeIdList) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.managerId = managerId;
		this.trainingId = trainingId;
		this.status = status;
		this.employeeIdList = employeeIdList;
	}

	@Override
	public String toString() {
		return "RequestTraining [employeeId=" + employeeId + ", employeeName=" + employeeName + ", managerId="
				+ managerId + ", trainingId=" + trainingId + ", status=" + status + ", employeeIdList=" + employeeIdList
				+ "]";
	}



}
