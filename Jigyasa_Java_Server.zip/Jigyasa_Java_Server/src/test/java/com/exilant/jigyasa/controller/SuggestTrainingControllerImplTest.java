package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;

import com.exilant.jigyasa.vo.SuggestTraining;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SuggestTrainingControllerImplTest {
	@Autowired
	private TestRestTemplate restTemplate;
	SuggestTraining testSuggestTraining = null;

	@Before
	public void setup() {
		testSuggestTraining = new SuggestTraining();
		testSuggestTraining.setEmployeeId(4343);
		testSuggestTraining.setTitle("Hibernate");
		testSuggestTraining.setDescription("Training On Hibernate");
	
	}

	@Test
	public void testRequestManagerToNominateForTraining() throws Exception {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.SUGGEST_TRAINING, testSuggestTraining,
				String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
