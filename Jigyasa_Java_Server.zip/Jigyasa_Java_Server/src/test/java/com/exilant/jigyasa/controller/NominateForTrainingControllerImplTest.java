/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 02-May-2017
  * NominateForTrainingControllerImplTest.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;

/**
 * @author lakshmi.bhat
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class NominateForTrainingControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;

	ScheduledTrainingNominee nominee = null;

	@Before
	public void setup() {
		ArrayList<Integer> nomineeIdList = new ArrayList<Integer>();
		nomineeIdList.add(4302);
		nomineeIdList.add(4343);
		nominee = new ScheduledTrainingNominee();
		nominee.setEmployeeId(4303);
		nominee.setNomineeId(nomineeIdList);
		nominee.setTrainingId(124);
	}

	@Test
	public void testNominateEmp() {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.NOMINATE_TRAINING, nominee,
				String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
