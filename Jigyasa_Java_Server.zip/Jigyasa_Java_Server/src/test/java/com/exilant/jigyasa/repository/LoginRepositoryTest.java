/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * LoginRepositoryTest.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author lakshmi.bhat
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LoginRepositoryTest {
	
	@Autowired
	LoginRepository loginRepository;
	
	@Test
	public void testGetEmployeeDetails() {
		assertNotNull(loginRepository.getEmployeeDetails("lakshmi.bhat@exilant.com"));
	}

}
