/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 03-May-2017
  * UpdateRequsetControllerImplTest.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UpdateRequsetControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;

	RequestTraining reqTrainingObj = null;

	@Before
	public void setup() {
		reqTrainingObj = new RequestTraining();
		ArrayList<Integer> employeeIdList = new ArrayList<Integer>();
		employeeIdList.add(4302);
		employeeIdList.add(4301);

		reqTrainingObj.setEmployeeIdList(employeeIdList);
		reqTrainingObj.setTrainingId(254);
		reqTrainingObj.setStatus("Approved");
	}

	@Test
	public void testUpdateRequestStatus() {	
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.UPDATE_REQUEST_STATUS, reqTrainingObj, String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
