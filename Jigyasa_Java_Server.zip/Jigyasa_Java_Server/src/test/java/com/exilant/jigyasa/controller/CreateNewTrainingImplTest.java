/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 03-May-2017
>  * CreateNewTrainingImplTest.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.CreateNewTraining;
import com.exilant.jigyasa.vo.Notification;
import com.exilant.jigyasa.vo.Schedule;
import com.exilant.jigyasa.vo.TrainerList;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CreateNewTrainingImplTest {

	@Autowired
	private TestRestTemplate restTemplate;
	Training training = null;
	List<Schedule> schedule = null;
	List<TrainerList> trainerList = null;
	Notification notification = null;
	CreateNewTraining testCreateNewTraining = null;

	@Before
	public void setup() {
		training = new Training();
		training.setTitle("RestServices5");
		training.setDescription("Rest Service");
		training.setSeats(12);
		training.setLink("www.rest.org");
		training.setImage("RestService.jpg");

		// List<String> schedule = new ArrayList<String>();
		schedule = new ArrayList<Schedule>();
		Schedule sc = new Schedule();
		sc.setLocation("Bannerghatta");
		sc.setStartDate("30-jan-2017");
		sc.setEndDate("31-jan-2017");
		schedule.add(sc);

		trainerList = new ArrayList<TrainerList>();
		TrainerList tl = new TrainerList();
		tl.setEmployeeId((long) 7777);
		trainerList.add(tl);

		notification = new Notification();
		notification.setType("immediate");
		notification.setSubject("New training added");
		notification.setContent("Invite your employees");
		notification.setCcListId("swathi.m@exilant.com");

		testCreateNewTraining = new CreateNewTraining();
		testCreateNewTraining.setTraining(training);
		testCreateNewTraining.setSchedule(schedule);
		testCreateNewTraining.setTrainerList(trainerList);
		testCreateNewTraining.setNotification(notification);

	}

	@Test
	public void testCreateNewTraining() throws Exception {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.CREATE_NEW_TRAINING,
				testCreateNewTraining, String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}
}
